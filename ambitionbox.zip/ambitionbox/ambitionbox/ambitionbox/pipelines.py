# import pymongo
# from pymongo import MongoClient, UpdateOne
# from scrapy.exceptions import DropItem

# class MongoDBPipeline:
#     def __init__(self, mongo_uri, mongo_db, batch_size=200):
#         self.mongo_uri = mongo_uri
#         self.mongo_db = mongo_db
#         self.batch_size = batch_size
#         self.client = MongoClient(self.mongo_uri)
#         self.db = self.client[self.mongo_db]
#         self.collection = self.db['rawcompanies']
#         self.buffer = []
    
#     @classmethod
#     def from_crawler(cls, crawler):
#         return cls(
#             mongo_uri=crawler.settings.get('MONGO_URI'),
#             mongo_db=crawler.settings.get('MONGO_DATABASE'),
#             batch_size=crawler.settings.get('BATCH_SIZE', 200)
#         )

#     def process_item(self, item, spider):
#         if not isinstance(item, dict):
#             raise DropItem(f"Expected a dictionary, got {type(item)}")
        
#         self.buffer.append(item)

#         if len(self.buffer) >= self.batch_size:
#             self.dump_to_mongo()
        
#         return item
    
#     def dump_to_mongo(self):
#         if not self.buffer:
#             return
        
#         operations = []
#         for item in self.buffer:
#             operations.append(
#                 UpdateOne({'rawData.url_hash': item['rawData']['url_hash']}, {'$set': item}, upsert=True)
#             )
        
#         self.collection.bulk_write(operations)
#         self.buffer.clear()  

#     def close_spider(self, spider):
#         self.dump_to_mongo() 
#         self.client.close()


import pymongo
from scrapy.exceptions import DropItem
from pymongo import UpdateOne
from datetime import datetime


class MongoDBPipeline:
    def __init__(self, mongo_uri, mongo_db, mongo_collection, batch_size=1000):
        # MongoDB connection setup
        self.client = pymongo.MongoClient(mongo_uri)
        self.db = self.client[mongo_db]
        self.collection = self.db[mongo_collection]
        self.batch_size = batch_size  # Batch size for inserting/updating in bulk
        self.buffer = []  # Buffer to accumulate operations before committing to MongoDB

    @classmethod
    def from_crawler(cls, crawler, *args, **kwargs):
        # Read MongoDB settings from Scrapy settings
        mongo_uri = crawler.settings.get('MONGO_URI')
        mongo_db = crawler.settings.get('MONGO_DATABASE')
        mongo_collection = crawler.settings.get('MONGO_COLLECTION')
        batch_size = crawler.settings.getint('BATCH_SIZE', 1000)  # Default batch size
        return cls(mongo_uri, mongo_db, mongo_collection, batch_size)

    def compare_fields(self, existing_doc, item):
        """
        Compare the fields of the existing document with the new item.
        Return fields that have changed and the status of the update.
        """
        update_fields = {}
        has_changes = False
        # Compare only the fields that are part of 'rawData' in the item
        for field, value in item['rawData'].items():
            if existing_doc['rawData'].get(field) != value:
                update_fields[f'rawData.{field}'] = value
                has_changes = True
        return update_fields, has_changes

    def process_item(self, item, spider):
        if not isinstance(item, dict):
            raise DropItem(f"Expected a dictionary, got {type(item)}")

        # Incremental check: find existing document by 'url_hash' (a unique identifier)
        existing_doc = self.collection.find_one({'rawData.url_hash': item['rawData']['url_hash']})

        if existing_doc:
            # Compare fields and add to update buffer if there are any changes
            update_fields, has_changes = self.compare_fields(existing_doc, item)
            if has_changes:
                update_fields['updatedAt'] = datetime.utcnow()  # Update timestamp
                item.update(update_fields)
                self.buffer.append(UpdateOne(
                    {'rawData.url_hash': item['rawData']['url_hash']},
                    {'$set': update_fields},
                    upsert=True  # Insert if not found
                ))
        else:
            # New entry, insert with creation timestamp
            item['createdAt'] = datetime.utcnow()
            item['updatedAt'] = datetime.utcnow()
            self.buffer.append(UpdateOne(
                {'rawData.url_hash': item['rawData']['url_hash']},
                {'$set': item},
                upsert=True  # Insert if not found
            ))

        # If the buffer has reached the batch size, write to MongoDB
        if len(self.buffer) >= self.batch_size:
            self.dump_to_mongo()

        return item

    def dump_to_mongo(self):
        """
        Write the batched operations (insert or update) to MongoDB.
        The buffer is cleared only after a successful bulk operation.
        """
        if not self.buffer:
            return

        try:
            # Perform bulk write operations to MongoDB
            result = self.collection.bulk_write(self.buffer)
            # Check if there were any upserts or updates, print a summary
            print(f"Inserted/Updated {len(result.bulk_api_result.get('nUpserted', 0))} new documents")
            print(f"Modified {len(result.bulk_api_result.get('nModified', 0))} documents")
            # Clear the buffer after a successful write
            self.buffer.clear()
        except Exception as e:
            # Log the error if any issues occur during the bulk write operation
            print(f"Error during MongoDB bulk operation: {e}")

    def close_spider(self, spider):
        """
        Ensure any remaining items in the buffer are written to MongoDB when the spider closes.
        """
        if self.buffer:
            self.dump_to_mongo()

