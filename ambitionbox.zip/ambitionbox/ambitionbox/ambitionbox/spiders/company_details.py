import hashlib
import json
import scrapy
from datetime import datetime
from bs4 import BeautifulSoup 

class CompanyDetailsSpider(scrapy.Spider):
    name = "company_details"
    allowed_domains = ["ambitionbox.com"]
    start_urls = ['https://www.ambitionbox.com/list-of-companies?campaign=desktop_nav&page=1']
    page_number = 1
    max_retries = 3
    retry_count = 0
        
    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'en-US,en;q=0.9',
        'cache-control': 'max-age=0',
        'priority': 'u=0, i',
        'cookie':'_t_ds=4159f78b1727096627-724159f78b-04159f78b; _clck=1fzveyb%7C2%7Cfph%7C0%7C1728; showChatbot=n; _ga=GA1.1.374424098.1727096631; bm_mi=11E5D726BB09A2167BA766ECAA3994B4~YAAQnv7UF9dGFy+TAQAAztppexn9kqfAOKXAkKAwNuxX9CWoz9jk6mwiG/nyd0YvBxXs4tk7K+45MhoBwjovg8YIt7gHg3TlcpIiR0QD9Gkk3h/jw3k0/zLtMf9ZAj4QOfp6HVs0BZf7ClgVyoU31p8Q0pZPBiWu/biJT1CBE68G4/eruUPwYTCGdAcIgBcg7vd0KI0U/SPddZuZ0wc5zLy32INxhvHKAglz0Ya/eNmuPzxY7f2PvuewwHDEe3NeGqeKeTXMgfRWO4XKFC44+9n50xQhCHgBh4LMy3yA6FN9JGtCBB0baefO5l5GlHZE192XX6ONLPH/Kl0zM3nlC0hL~1; ak_bmsc=5B9488DA5A3716D86BC10CC52CE92797~000000000000000000000000000000~YAAQnv7UF2NHFy+TAQAATN9pexkf+dJi+UqOwgpabiKXMMbrqq/ruuydCKWdtRM//vo02BkQBXw73qaEbIe9ra3Z2QWP2yIVYUr4DxumAOWjNWVGFFBTqM1o/SLhK9UzItlUXax5OaMXGJVKhpd2nfHFzFtfR9PBVFfIbNeRhiXclSh3XxaRv96GR1FCZ22Dns/FCwfFdf584YpqPJ05aV6cz3xJddQzWGA3Pt0vQKLgmshLWSn7pUSOo23hxccg02kFLEgqmP+n6pt/HFf8/Pi0UxNMlK98xQLbIGnT903dWkyHEpJYrqRyc0+y0SlcxHzvSr5sKVeJzTJvC6I6q0LKNkYEPuGIt9iQKMEaFtP1bLDMzEcTaT4qdO+lZIfSeLztBBubgFA0uCy6H/d+JdMR+nbuYU3AGE83JcalYAY/AO4VAehjGpKRIwpeu+9Z2m2SIzDGc+1RMC2DQ1AUOXZgpYmoHZUP+kWeVG4iFq+ld7WzMkck81qkuFOwI8g4ui8fNxlO2BI=; _ga_HV7DJVVBCW=GS1.1.1732942348.49.1.1732942356.52.0.0; bm_sv=826A717E41C1BBA2D459345D27E12D49~YAAQnv7UF5NKFy+TAQAAEwZqexmpax0ZZFI7wtSUKTetf/J7DtwBAXKhCas89IMSCacvic9HcFcMNhYu7zZjLxSKStXqN5X+r+R03j9D39/lA6nZycBwW5kKOFBZ9ihitVLLkeiGG3gxO7dfbKcWCFBOvt0dOjOrod27dGqHWVFgekE7iwhcNyvMWn1YYiTokXr+xvRU/JnoPP4c5gzbcnzfaafcvTfzdson0qUuKcPb+oFtXbHyStOGFajvnMivmfy017Q=~1; HOWTORT=ul=1732942368269&r=https%3A%2F%2Fwww.ambitionbox.com%2Flist-of-companies%3Fcampaign%3Ddesktop_nav%26page%3D1&hd=1732942355042',
        'sec-ch-ua': 'Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
        'if-none-match' : '"4d761-iSaHhTuIb+rJYLoCN/Q/N3QlDY4"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
    }

    def parse(self, response):
        company_urls = response.xpath('//meta[@itemprop="url"]/@content').getall()

        if company_urls:
            for c_url in company_urls:
                if "list-of-companies?campaign=desktop_nav" in c_url:
                    continue

                full_url = response.urljoin(c_url.strip())
                yield scrapy.Request(full_url, callback=self.parse_details, headers=self.headers)

            next_page_url = f'https://www.ambitionbox.com/list-of-companies?campaign=desktop_nav&page={self.page_number + 1}'
            self.page_number += 1
            self.retry_count = 0

            yield scrapy.Request(next_page_url, callback=self.parse, headers=self.headers)
        else:
            if self.retry_count < self.max_retries:
                self.retry_count += 1
                self.logger.warning(f"No data found, retrying {self.retry_count}/{self.max_retries} for page {self.page_number}.")
                
                next_page_url = f'https://www.ambitionbox.com/list-of-companies?campaign=desktop_nav&page={self.page_number}'
                yield scrapy.Request(next_page_url, callback=self.parse, headers=self.headers, dont_filter=True)
            else:
                self.logger.info(f"No more data or reached the last page after {self.max_retries} retries.")

    def parse_details(self, response):
        json_ld = response.xpath('//script[@id="__NEXT_DATA__"]/text()').get()

        if json_ld:
            cd = json.loads(json_ld)

            url = response.url
            url_hash = hashlib.md5(url.encode()).hexdigest() if url else None

            company_name = cd['props']['pageProps']['companyMetaInformation'].get('shortName', 'N/A')
            industry = cd['props']['pageProps']['companyMetaInformation']['primaryIndustry'][0]['name'] if cd['props']['pageProps']['companyMetaInformation'].get('primaryIndustry') else ''
            rating =  cd['props']['pageProps']['companyMetaInformation']['rating']
            opps_review = cd['props']['pageProps']['companyStatsData']
            
            reviews_count = None
            jobs_count = None

            for item in opps_review:
                if item['name'] == 'Reviews':
                    reviews_count = item.get('count', 0)
                elif item['name'] == 'Jobs':
                    jobs_count = item.get('count', 0)

            raw_description = cd['props']['pageProps']['companyMetaInformation'].get('description', '')
            raw_mission = cd['props']['pageProps']['companyMetaInformation'].get('mission', '')
            raw_vision = cd['props']['pageProps']['companyMetaInformation'].get('vision', '')

            clean_description = self.remove_html_tags(raw_description)
            clean_mission = self.remove_html_tags(raw_mission)
            clean_vision = self.remove_html_tags(raw_vision)

            description = {
                "description": {
                    "text": clean_description,
                    "html": raw_description
                },
                "mission": {
                    "text": clean_mission,
                    "html": raw_mission
                },
                "vision": {
                    "text": clean_vision,
                    "html": raw_vision
                }
            }

            website = cd['props']['pageProps']['companyMetaInformation'].get('website', 'N/A')
            logo = cd['props']['pageProps']['companyHeaderData'].get('highQualityLogo', '')
            ceo_name = cd['props']['pageProps']['companyMetaInformation'].get('ceo', '')
            founders = cd['props']['pageProps']['companyMetaInformation'].get('founders', [])
            leadership = [
                {
                    'url': '',
                    'logo': '',
                    'name': ceo_name,
                    'position': 'ceo'
                }
            ]
            for founder in founders:
                leadership.append({
                    'url': '',
                    'logo': '',
                    'name': founder,
                    'position': 'founder'
                })
                        
            benefits_data = cd['props']['pageProps'].get('benefits', {})
            benefits = [{"title": b.get('name', '')} for b in benefits_data.get('benefits', [])] if isinstance(benefits_data, dict) else []
            commitments = [b.get('name', '') for b in benefits_data.get('benefits', [])] if isinstance(benefits_data, dict) else []
            
            gallery = [photo.get('Url', '') for photo in cd['props']['pageProps'].get('photosData', {}).get('data', {}).get('Photos', [])]
            
            headquarters_data = cd['props']['pageProps']['companyHeaderData'].get('infoTags', [{}])
            headquarters = headquarters_data[0].get('name', 'N/A') if headquarters_data else 'N/A'

            headquarters_cleaned = headquarters.replace('HQ - ', '').strip()
            parts = headquarters_cleaned.split(', ')
            city, state, country = '', '', ''
            if len(parts) == 3:
                city, state, country = parts
            elif len(parts) == 2:
                city, country = parts[0], parts[1]
            elif len(parts) == 1:
                city = parts[0]
            location = {'area': '', 'city': city, 'state': state, 'country': country}

            financial_insight = {
                "currentStage": "",
                "totalFunding": {"value": "", "currency": ""},
                "revenue": {"value": "", "currency": ""},
                "profitability": {"value": "", "currency": ""},
                "expenses": {"value": "", "currency": ""},
                "cashFlow": {"value": "", "currency": ""},
                "earningsPerShare": {"value": "", "currency": ""},
                "keyInvestors": ""
            }

            company_data = {
                "portal": "Ambitionbox",  
                "rawData": {
                    "url": url,
                    "url_hash": url_hash,
                    "company_name": company_name,
                    "rating" : rating,
                    "reviewsCount" : reviews_count,
                    "openings" : jobs_count,
                    "commitments" : commitments,
                    "industry": industry,
                    "location": location,
                    "description": description,
                    "website": website,
                    "logo": logo,
                    "leadership": leadership,
                    "companyInsight": {
                        "financialInsight": financial_insight,
                        "gallery": gallery,
                        "benefits": benefits  
                    }
                },
                "createdAt": datetime.utcnow(),
                "updatedAt": datetime.utcnow(),
                "isDumped": False
            }

            yield company_data
